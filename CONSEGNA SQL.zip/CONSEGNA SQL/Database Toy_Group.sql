USE toy_group;

CREATE TABLE Category (
Category_ID INT PRIMARY KEY AUTO_INCREMENT,
Name VARCHAR (255));

CREATE TABLE Product (
Product_ID INT PRIMARY KEY AUTO_INCREMENT,
Name VARCHAR (255),
Category_ID INT,
Unit_price DECIMAL (10,2),
StockQuantity INT,
FOREIGN KEY (Category_ID) REFERENCES Category (Category_ID));

CREATE TABLE Region (
Region_ID INT PRIMARY KEY AUTO_INCREMENT,
Region_Name VARCHAR (255));

CREATE TABLE State (
State_ID INT PRIMARY KEY AUTO_INCREMENT,
State_Name VARCHAR (25),
Region_ID INT,
FOREIGN KEY (Region_ID) REFERENCES Region (Region_ID));

CREATE TABLE SALES (
Sales_ID INT PRIMARY KEY AUTO_INCREMENT,
Product_ID INT,
Region_ID INT,
Data_ordine DATE,
Sold_Quantity INT,
FOREIGN KEY (Product_ID) REFERENCES Product (Product_ID),
FOREIGN KEY (Region_ID) REFERENCES Region (Region_ID));

INSERT INTO Category (Name) VALUES
('Action Figure'),
('Giochi di società'),
('Giocattoli educativi'),
('Bambole e peluche'),
('Puzzle e giochi di costruzione'),
('Giochi per esterni'),
('Giochi artistici e creativi'),
('Veicoli giocattolo'),
('Giochi elettronici'),
('Giochi per neonati');

INSERT INTO Product (Name, Category_ID, Unit_price, StockQuantity) VALUES
('Action Figure - Supereroe', 1, 29.99, 50),
('Gioco di carte - Strategia', 2, 19.99, 20),
('Giocattolo educativo - Scienza', 3, 34.99, 45),
('Bambola interattiva', 4, 49.99, 30),
('Puzzle 3D - Castello', 5, 24.99, 60),
('Pallone da calcio', 6, 14.99, 80),
('Set di pittura per bambini', 7, 19.99, 75),
('Macchinina telecomandata', 8, 39.99, 40),
('Console portatile', 9, 149.99, 25),
('Sonaglio per neonati', 10, 9.99, 90);

INSERT INTO Region (Region_Name) VALUES
('Europa'),
('America'),
('Asia'),
('Africa'),
('Oceania');

INSERT INTO State (State_Name, Region_ID) VALUES
('Italia', 1),
('Francia', 1),
('Germania', 1),
('Spagna', 1),
('Stati Uniti', 2),
('Canada', 2),
('Brasile', 2),
('Argentina', 2),
('Cina', 3),
('Giappone', 3),
('India', 3),
('Corea del Sud', 3),
('Nigeria', 4),
('Egitto', 4),
('Sudafrica', 4),
('Kenya', 4),
('Australia', 5),
('Nuova Zelanda', 5),
('Papua Nuova Guinea', 5),
('Fiji', 5);

INSERT INTO SALES (Product_ID, Region_ID, Data_ordine, Sold_Quantity) VALUES
(1, 2, '2024-02-15', 10),
(2, 1, '2024-02-20', 5),
(3, 3, '2024-02-10', 8),
(4, 4, '2024-02-18', 15),
(5, 5, '2024-02-08', 22),
(6, 2, '2024-02-22', 12),
(7, 3, '2024-02-19', 7),
(8, 1, '2024-02-13', 9),
(9, 4, '2024-02-17', 6),
(10, 5, '2024-02-09', 14);