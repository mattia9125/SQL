USE TOY_GROUP;

-- Verificare che i campi definiti come PK siano univoci. 

SELECT COUNT(DISTINCT Category_ID ) AS Chiave_Univoca, COUNT(*) AS Conteggio_Righe_Totali
FROM category;

SELECT COUNT(DISTINCT Product_ID ) AS Chiave_Univoca, COUNT(*) AS Conteggio_Righe_Totali
FROM product;

SELECT COUNT(DISTINCT Region_ID) AS Chiave_Univoca, COUNT(*) AS Conteggio_Righe_Totali
FROM region;

SELECT COUNT(DISTINCT Sales_ID ) AS Chiave_Univoca, COUNT(*) AS Conteggio_Righe_Totali
FROM Sales;

SELECT COUNT(DISTINCT State_ID ) AS Chiave_Univoca, COUNT(*) AS Conteggio_Righe_Totali
FROM State;

-- Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.

SELECT Product.Name, YEAR(Sales.Data_ordine) AS Anno, SUM(Sales.Sold_Quantity * Product.Unit_price) AS FatturatoTotale
FROM Product
JOIN Sales USING (Product_ID)
GROUP BY Product.Name, YEAR(Sales.Data_ordine)
ORDER BY Product.Name, Anno;

-- Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. 

SELECT State.State_Name, YEAR(Sales.Data_ordine) AS Anno, SUM(Sales.Sold_Quantity * Product.Unit_price) AS FatturatoTotale
FROM Product
JOIN Sales USING (Product_ID)
JOIN State ON State.State_ID = Sales.Region_ID
GROUP BY State.State_Name, YEAR(Sales.Data_ordine)
ORDER BY YEAR(Sales.Data_ordine), FatturatoTotale DESC;

-- Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?

SELECT Category.Name, SUM(Sales.Sold_Quantity) AS TotaleVendite
FROM Product
JOIN Sales USING (Product_ID)
JOIN Category USING (Category_ID)
GROUP BY Category.Name
ORDER BY TotaleVendite DESC
LIMIT 1;

-- Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).

SELECT Product.Name, MAX(Sales.Data_ordine) AS UltimaDataVendita
FROM Product
INNER JOIN Sales ON Sales.Product_ID = Product.Product_ID
GROUP BY Product.Name
ORDER BY Product.Name;

-- Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. 

SELECT Product.Name, Product.StockQuantity
FROM Product
LEFT JOIN Sales USING (Product_ID)
WHERE Sales.Product_ID IS NULL
ORDER BY Product.Name;

SELECT Product.Name, Product.StockQuantity
FROM Product
WHERE NOT EXISTS (
    SELECT *
    FROM Sales
    WHERE Sales.Product_ID = Product.Product_ID
)
ORDER BY Product.Name;